<?php
/**
 * @package WordPress
 * @subpackage ProBlue
 */
?>
		</div>
		<?php get_sidebar(); ?>
	</div>
	<div id="footer">
		<ul>
			<li class="first<?php if(is_home()) echo ' current_page_item'; ?>"><a href="<?php bloginfo('url'); ?>">Home</a></li>
			<?php wp_list_pages('title_li=&depth=1'); ?>
		</ul>
		<div class="copyright">Copyright &copy; 2010 <a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> | Designed by <a href="http://www.BingoDazzle.com">Bingo</a> - The Web Design Experts</div>
		<?php wp_footer(); ?>
	</div>
</div>
</body>
</html>