<?php
/**
 * @package WordPress
 * @subpackage ProBlue
 */
get_header();
?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="post page" id="post-<?php the_ID(); ?>"><div class="post-bottom"><div class="post-top">
	<h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
	<div class="entry">
		<?php the_content(); ?>
		<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
	</div>
</div></div></div>

<?php comments_template(); ?>

<?php endwhile; endif; ?>

<?php get_footer(); ?>