<?php
/**
 * @package WordPress
 * @subpackage ProBlue
 */
get_header();
?>

<p>Sorry but the page you requested could not be found</p>

<?php get_footer(); ?>